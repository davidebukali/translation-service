<?php
header("Content-Type: application/json; charset=UTF-8");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header("Access-Control-Allow-Headers: Content-Type, Process-Data");

require_once 'class.manage.php';

$postdata = file_get_contents("php://input");

if (isset($postdata)) {
  $request = json_decode($postdata);
  saveData($request);
}else {
  $response["success"] = 0;
  $response["message"] = "Post data not received";
  http_response_code(200);
  echo json_encode($response);
}

function saveData($meta){
  $connection = new ManageConnection();
  
  $stmt = $connection->runQuery("INSERT INTO translationDictionary(originalText, translatedText, originalLang, translatedLang, thedate) 
    VALUES(:o_text, :t_text, :o_lang, :t_lang, :t_date)");
  date_default_timezone_set('Africa/Kampala');
  $thetime = date('Y-m-d H:i:s', time());
  $stmt->execute(array(
    ":o_text"=>$meta->origText,
    ":t_text"=>$meta->transText,
    ":o_lang"=>$meta->origLang,
    ":t_lang"=>$meta->transLang,
    ":t_date"=>$thetime
  ));

  $response["success"] = 1; 
  $response["message"]  = "Saved";
  http_response_code(200);
  echo json_encode($response);
  
}

?>