<?php
header("Content-Type: application/json; charset=UTF-8");
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');

require_once 'class.manage.php';

$connection = new ManageConnection();
 
  $stmt = $connection->runQuery("SELECT * FROM translationDictionary");
  $stmt->execute();
  $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
 
  if($stmt->rowCount() > 0)
  {
    $response["success"] = 1;
    $response["data"] = $row;

    echo json_encode($response);
  }
  else
  {
    $response["success"] = 0;
    $response["data"] = "No Translations found";
    echo json_encode($response);
  }
?>